var number = [1, 2, 3, 4, 5, 6, 7, 8, 9];
if (number[0] == 1) {
    document.write("1st");
}
document.write("<br>");
if (number[1] == 2) {
    document.write("2nd");
}
document.write("<br>");
if (number[2] == 3) {
    document.write("3rd");
}
document.write("<br>");
if (number[3] == 4) {
    document.write("4th");
}
document.write("<br>");
if (number[4] == 5) {
    document.write("5th");
}
document.write("<br>");
if (number[5] == 6) {
    document.write("6th");
}
document.write("<br>");
if (number[6] == 7) {
    document.write("7th");
}
document.write("<br>");
if (number[7] == 8) {
    document.write("8th");
}
document.write("<br>");
if (number[8] == 9) {
    document.write("9th");
}
else {
    document.write("nothing print");
}
