function car (manufacture, model){
    document.write(manufacture+"  "+"Subaru"+"  "+model+" "+"Outback"+"  "+"color:blue");
    document.write("<br>");
    document.write(manufacture+" "+"Honda"+"  "+model+" "+"Accord"+"  "+"color:red");
}
 car("manufacture:", "model:");
         