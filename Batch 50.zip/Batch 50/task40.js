function car(artist, title) {
    document.write(artist + "Aima bag" + "  " + title + " " + "khani suno");
    document.write("<br>");
    document.write(artist + " " + "Atif aslam" + "  " + title + " " + "sange_maa");
}
car("artist:", "title:");
