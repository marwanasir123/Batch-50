var user_names = [];
if (user_names[0] == 'admin') {
    document.write("hello admin would you to login");
}
else {
    document.write("we need to find some users!");
}
