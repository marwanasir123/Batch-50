var person_Name ="\tmarwa nasir\n";
document.write("marwa nasir");
document.write("<br>" );
document.write(person_Name);
