var fav_fruits = ['banana', 'apple', 'blueberies'];
if (fav_fruits[0] == 'banana') {
    document.write("you like banana");
}
document.write("<br>");
if (fav_fruits[1] == 'apple') {
    document.write("you like apple");
}
document.write("<br>");
if (fav_fruits[2] == 'blueberies') {
    document.write("you like blueberies");
}
document.write("<br>");
if (fav_fruits[3] == 'pear') {
    document.write("you like pear");
}
document.write("<br>");
if (fav_fruits[4] == 'pear') {
    document.write("you like pear");
}
