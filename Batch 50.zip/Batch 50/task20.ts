var array = ["lahore","islamabad","sargodha","faisalabad"];
document.write(array +"");