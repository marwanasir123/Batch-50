var personName = "Hello Eric";
document.write(personName);

