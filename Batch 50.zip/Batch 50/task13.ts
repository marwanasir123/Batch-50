var transport = ["motercycle","car","cycle"];
document.write(transport[0]+ '"'+'i would like to own motercycle'+'"');
document.write("<br>");
document.write(transport[1]+ '"'+'i would like to own car'+'"');
document.write("<br>");
document.write(transport[2]+ '"'+'i would like to own cycle'+'"');