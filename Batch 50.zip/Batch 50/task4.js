document.write('Albert Einstein once said,' + '"A person who never made a mistake nevr tired anything"');
