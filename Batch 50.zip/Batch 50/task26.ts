var alien_color = "green";
if(alien_color=='green'){
    document.write("player just earn 5 point");
}
else{
    document.write("player just earn 10 point");
}
document.write("<br>");
var alien_color = "yellow";
if(alien_color=='yellow'){
document.write("player just earn 10 poitn")
}
else{
    document.write("player just earn 5 point")
}