var Name = "Marwa Nasir";
document.write(Name.toLowerCase());
document.write("<br>");
document.write(Name.toUpperCase());
document.write("<br>");

function tittle_Case(str){
  str = str.toLowerCase().split(' ');
  for (var i = 0; i < str.length; i++) {
    str[i] = str[i].charAt(0).toUpperCase() + str[i].slice(1); 
  }
  return str.join(' ');
}
document.write(tittle_Case("marwa nasir"));