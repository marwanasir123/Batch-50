var alien = "green";
if (alien == 'green') {
    document.write("player earn 5 points");
}
else
    document.write("player earned 10 points");
document.write("<br>");
var alien = "yellow";
if (alien == 'yellow') {
    document.write("player earned  10 points");
}
else {
    document.write("nothing print");
}
document.write("<br>");
var alien = "red";
if (alien == 'red') {
    document.write("player earned  15 points");
}
else {
    document.write("player earned  10 points");
}
