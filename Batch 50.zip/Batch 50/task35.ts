var animal = ["Thorny Dragon","Komodo Dragon","Gila Monster "];
let ani= "";
for(let i = 0; i<animal.length; i++){
    ani +=animal[i]+"<br>" 
}
document.write(ani);
document.write("<br>");
let texts = "";
for(let i = 0; i<animal.length; i++){
    texts +="i like"+" "+animal[i]+"pizza"+"<br>"}
    document.write(texts);
    document.write("<br>");
    document.write("these animal has log tail!");