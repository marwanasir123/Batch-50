let car={ name: 'marwa', age: 30, year: 2005 } 
console.log(car);
    
  