var personName = '"Hello Eric';
document.write(personName+"," +'would you like to lear some python today?"');
