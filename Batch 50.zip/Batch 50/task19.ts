var guest = ["marwa","fatima"]
var message = ("marwa and fatima invited for dinner")
document.write(guest +","+"<br>"+ message)