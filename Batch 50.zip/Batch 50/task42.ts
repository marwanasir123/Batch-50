var magicians =["husnain","ali","asad","fatima"];
    function show_magicians(magicians){
        document.write(magicians);
}
show_magicians(magicians);
document.write("<br>");
document.write("<br>");
function make_great(magicians){
document.write(magicians[0]+" "+"the great"+"<br>");
document.write(magicians[1]+" "+"the great"+"<br>");
document.write(magicians[2]+" "+"the great"+"<br>");
document.write(magicians[3]+" "+"the great"+"<br>");
}
make_great(magicians);