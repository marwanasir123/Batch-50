var famous_person = "Muhammad Ali";
var message= "Don't count the days makethe days count ";
document.write(famous_person + " , "+'"'+message+'"')
