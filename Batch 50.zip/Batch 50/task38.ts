function describe_city(city, country){
    document.write("<br>");
document.write("Chiniot is in"+" "+country);
document.write("<br>")
document.write("Lahore is in"+" "+country);

}
document.write("Neuse is in germany");
describe_city('', 'pakistan');

