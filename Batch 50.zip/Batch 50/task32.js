var current_users = ["marwa", "maha", "saman", "faiza", "husnain"];
var new_users = ["husnain", "fatima", "faiza", "mahida", "aiza"];
if (current_users[0] == new_users[0]) {
    document.write("enter new person");
}
else {
    document.write("user name is available");
}
document.write("<br>");
if (current_users[1] == new_users[1]) {
    document.write("enter new person");
}
else {
    document.write("user name is available");
}
document.write("<br>");
if (current_users[2] == new_users[2]) {
    document.write("enter new person");
}
else {
    document.write("user name is available");
}
document.write("<br>");
if (current_users[3] == new_users[2]) {
    document.write("enter new person");
}
else {
    document.write("user name is available");
}
document.write("<br>");
if (current_users[4] == new_users[0]) {
    document.write("enter new person");
}
else {
    document.write("user name is available");
}
