function make_shir(size,message){
    
    return make_shir(size,message);
   };
   document.write("size:"+" "+"shirt size are large");
   document.write("<br>");
   document.write("message:"+" "+"i love this shirt");
   document.write("<br>");
   document.write("<br>");
   document.write("size:"+" "+"shirt size are meduim");
   document.write("<br>");
   document.write("message:"+" "+"i like this shirt");
   document.write("<br>");
   document.write("<br>");
   document.write("size:"+" "+"shirt size are short");
   document.write("<br>");
   document.write("message:"+" "+"i don't like this shirt");