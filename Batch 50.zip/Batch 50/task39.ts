function city_country(city,country){
    document.write(city+ ","+ country);
    document.write("<br>");
    document.write(city+ ","+ country);
    document.write("<br>");
    document.write(city +","+ country);
}
city_country("Lahore","Pakistan");