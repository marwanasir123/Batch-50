var invite = ["marwa", "maha", "husnain"];
document.write(invite[0] + "," + "please come to dinner");
document.write("<br>");
document.write(invite[1] + "," + "please come to dinner");
document.write("<br>");
document.write(invite[2] + "," + "please come to dinner");
