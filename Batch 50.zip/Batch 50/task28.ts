var person_age = "1 year old";
if(person_age< '2 year old'){
    document.write("person is a baby");
}
var person_age = "2 year old";
if(person_age< '2 year old'){
    document.write("person is a toddler");
}
document.write("<br>");
var person_age = "4 year old";
if(person_age< '13 year old'){
    document.write("person is a kid");
}
document.write("<br>");
var person_age = "13 year old";
if(person_age< '20 year old'){
    document.write("person is a teenager");
}
document.write("<br>");
var person_age = "20 year old";
if(person_age< '65 year old'){
    document.write("person is a adult");
}
document.write("<br>");
var person_age = "65 year old";
if(person_age <= '65 year old'){
    document.write("person is a elder");
}
else{
    document.write("nobody");

}