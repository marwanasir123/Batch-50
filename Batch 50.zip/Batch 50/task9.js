var favorite_number = 14;
var message = "My favorite number is 14";
document.write(favorite_number + "," +'"'+message+'"');
