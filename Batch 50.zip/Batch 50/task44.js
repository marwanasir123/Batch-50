function sandwich(items) {
    document.write(items + "" + "turky sandwich! " + "<br>");
    document.write("hello please add cheez....." + "<br>");
    document.write("hello please no cheez....." + "<br>");
    document.write("<br>");
    document.write(items + "" + "pakistani sandwich! " + "<br>");
    document.write("hello please make less spcy....." + "<br>");
    document.write("hello please make sandwich..." + "<br>");
    document.write("<br>");
    document.write(items + "" + "indian sandwich! " + "<br>");
    document.write("hello please make another....." + "<br>");
    document.write("hello please make sandwich..." + "<br>");
}
sandwich("making");
