var arry_location = ["murree","islamabad","lahore","uk","paris"];
document.write('"'+'original order: '+'"'+" "+arry_location +"");
document.write("<br>");
 arry_location.sort();
document.write('"'+'Alphabetic order: '+'"'+" "+arry_location +"");
document.write("<br>");
document.write('"'+'original order: '+'"'+" "+arry_location +"");
document.write("<br>");
arry_location.reverse();
document.write('"'+'Reverse order: '+'"'+" "+arry_location +"");
document.write("<br>")
arry_location.reverse();
document.write('"'+'Again Reverse order: '+'"'+" "+arry_location +"");
document.write("<br>")
arry_location.sort();
document.write('"'+'Sorted order: '+'"'+" "+arry_location +"");
document.write("<br>")
arry_location.sort().reverse();
document.write('"'+'Sorted reverse alphabetic order: '+'"'+" "+arry_location +"");
