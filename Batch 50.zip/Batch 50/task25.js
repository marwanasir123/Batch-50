var alien_color = "green";
if (alien_color == 'green') {
    document.write("player just earned 5 points");
}
if (alien_color == 'red') {
    document.write("player just earned 5 points");
}
