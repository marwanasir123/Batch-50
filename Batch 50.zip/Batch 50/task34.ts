var fav_pizzas= ["pepperoni", "hawaiian","veggie"]
let main= "";
for(let i = 0; i<fav_pizzas.length; i++){
    main +=fav_pizzas[i]+"<br>" 
}
document.write(main);
document.write("<br>");
let text = "";
for(let i = 0; i<fav_pizzas.length; i++){
    text +="i like"+" "+fav_pizzas[i]+"pizza"+"<br>"}
    document.write(text);
    document.write("<br>");
    document.write("i really love pizza!");