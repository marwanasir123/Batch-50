var array = ["maewa", "admin","eric","maha","ali"];
if(array[1]){
    document.write("Hello admin , would you like to see a status report?");
}
document.write("<br>");
if(array[0]){
document.write(array[0]+","+'"'+ 'thanks you for logging report'+'"');
}
document.write("<br>");
if(array[2]){
    document.write(array[2]+","+'"'+ 'thanks you for logging report'+'"');
}
document.write("<br>");
if(array[3]){
    document.write(array[3]+","+'"'+ 'thanks you for logging report'+'"');
}
document.write("<br>");
if(array[4]){
    document.write(array[4]+","+'"'+ 'thanks you for logging report'+'"');
}
else{
    document.write("nothing anything print");
}