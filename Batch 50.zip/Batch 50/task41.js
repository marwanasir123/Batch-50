var magicians = ["husnain", "ali", "asad", "fatima"];
function show_magicians(magicians) {
    document.write("\n" + magicians);
}
show_magicians(magicians);
