function make_shirt(size,message){
    
 return make_shirt(size,message);
};
document.write("size:"+" "+"shirt size should be 34");
document.write("<br>");
document.write("message:"+" "+"i love this shirt");