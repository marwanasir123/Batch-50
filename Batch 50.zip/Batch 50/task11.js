var personName = ["marwa", "maha", "samen", "fatima"];
document.write(personName[0]);
document.write("<br>")
document.write(personName[1]);
document.write("<br>")
document.write(personName[2]);
document.write("<br>")
document.write(personName[3]);
document.write("<br>")
document.write(personName + "");
