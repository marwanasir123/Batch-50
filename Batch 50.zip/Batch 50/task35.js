var animal = ["Thorny Dragon", "Komodo Dragon", "Gila Monster "];
var ani = "";
for (var i = 0; i < animal.length; i++) {
    ani += animal[i] + "<br>";
}
document.write(ani);
document.write("<br>");
var texts = "";
for (var i = 0; i < animal.length; i++) {
    texts += "i like" + " " + animal[i] + "pizza" + "<br>";
}
document.write(texts);
document.write("<br>");
document.write("these animal has log tail!");
