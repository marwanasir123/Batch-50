var fav_pizzas = ["pepperoni", "hawaiian", "veggie"];
var main = "";
for (var i = 0; i < fav_pizzas.length; i++) {
    main += fav_pizzas[i] + "<br>";
}
document.write(main);
document.write("<br>");
var text = "";
for (var i = 0; i < fav_pizzas.length; i++) {
    text += "i like" + " " + fav_pizzas[i] + "pizza" + "<br>";
}
document.write(text);
document.write("<br>");
document.write("i really love pizza!");
