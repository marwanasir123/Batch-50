console.log(5+3);
console.log(5*3);
console.log(5-3);
console.log(5/3);