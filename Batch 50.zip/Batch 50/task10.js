var Name = "marwa";
var task4 = "tuesday-18-july";
var task5 = "tuesday-18-july";
document.write(Name+"<br>"+ task4+"<br>"+task5+"<br>"+ '"'+'in task4 and task5 i print the famous_person name and quotes'+'"');
