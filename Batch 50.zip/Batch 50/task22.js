var fruit = ["bananna", "apple", "plum"];
document.write("index Error:" + fruit[4]);
document.write("<br>");
document.write("right answer:" + fruit[1]);
