var string1 = "marwa";
var string2 = "maha";
console.log(string1 == string2);
var string3 = "maha";
console.log(string3 == string2);
var case1 = "hello";
//---------------------------lowecase---
if (case1.toLowerCase()) {
    console.log(true);
}
else {
    console.log(false);
}
var case2 = "hello";
if (case2.toUpperCase()) {
    console.log(false);
}
else {
    console.log(true);
}
//----------------numverical----------
var a = 5;
var b = 6;
if (a == b) {
    console.log(true);
}
else {
    console.log(false);
}
var a = 5;
var b = 5;
if (a == b) {
    console.log(true);
}
else {
    console.log(false);
}
//--------------------greater than------------
var a = 10;
var b = 12;
if (a < b) {
    console.log(true);
}
else {
    console.log(false);
}
var a = 10;
var b = 12;
if (a > b) {
    console.log(false);
}
else {
    console.log(true);
}
//-----------------------greater than and equal than--------
var a = 10;
var b = 9;
if (a <= b) {
    console.log(false);
}
else {
    console.log(true);
}
var a = 10;
var b = 9;
if (a >= b) {
    console.log(false);
}
else {
    console.log(true);
}
//-------------------and or operator--------
var a = 10;
var b = 11;
console.log(a == 10 && b == 12);
console.log(a == 10 || b == 11);
//-----------------item in an array---------
var num = [1, 2, 3, 4];
console.log(num.includes(5));
console.log(num.includes(2));
