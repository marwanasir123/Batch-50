var person_name=["marwa","maha","samen"];
var message = "welcome to my course";
document.write(person_name[0]+","+'"'+message+'"'+"<br>");
document.write(person_name[1]+","+'"'+message+'"'+"<br>");
document.write(person_name[2]+","+'"'+message+'"'+"<br");
document.write(person_name[3]+","+'"'+message+'"'+"<br");